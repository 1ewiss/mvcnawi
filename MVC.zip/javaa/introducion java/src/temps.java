
import ejemplo.temp.Temperatura;



public class temps {
    public static void main(String[] args) {
        Temperatura temperatura = new Temperatura();

        // Convertir Celsius a Fahrenheit
        double fahrenheit = temperatura.celsiusAFahrenheit(25);
        System.out.println("25 grados Celsius son: " + fahrenheit + " grados Fahrenheit.");

        // Convertir Fahrenheit a Celsius
        double celsius = temperatura.fahrenheitACelsius(77);
        System.out.println("77 grados Fahrenheit son: " + celsius + " grados Celsius.");
    }
}