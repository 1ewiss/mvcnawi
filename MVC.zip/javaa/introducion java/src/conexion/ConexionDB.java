package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/agencia_turistica";
        String usuario = "root";      
        String contrasena = "";          

        return DriverManager.getConnection(url, usuario, contrasena);
    }
}