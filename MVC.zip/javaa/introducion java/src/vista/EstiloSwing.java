package vista;

import java.awt.*;

public class EstiloSwing {
    public static final Color COLOR_FONDO = new Color(0xF5F5DC);       // Crema
    public static final Color COLOR_PRIMARIO = new Color(0xE14B3D);    // Rojo anaranjado
    public static final Color COLOR_SECUNDARIO = new Color(0x2F4F4F);  // Verde oscuro
    public static final Color COLOR_VERDE_CLARO = new Color(0x5A8F7B); // Verde claro opcional

    public static final Font FUENTE_TITULO = new Font("SansSerif", Font.BOLD, 24);
    public static final Font FUENTE_NORMAL = new Font("SansSerif", Font.PLAIN, 16);
}
