package vista;

import controlador.ControladorPaqueteTuristico;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import modelo.*;

public class VistaPaqueteTuristico extends JFrame {
    private JMenuBar menuBar;
    private JMenu menu;
    private JMenuItem miAgregar, miListar, miBuscar, miEditar, miEliminar;
    private ControladorPaqueteTuristico controlador;

    public VistaPaqueteTuristico() {
        controlador = new ControladorPaqueteTuristico();
        setTitle("Gestión de Paquetes Turísticos");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        configurarMenu();
    }

    private void configurarMenu() {
        menuBar = new JMenuBar();
        menu = new JMenu("Opciones");
        menuBar.add(menu);

        miAgregar = new JMenuItem("Agregar");
        miListar = new JMenuItem("Listar");
        miBuscar = new JMenuItem("Buscar");
        miEditar = new JMenuItem("Editar");
        miEliminar = new JMenuItem("Eliminar");

        menu.add(miAgregar);
        menu.add(miListar);
        menu.add(miBuscar);
        menu.add(miEditar);
        menu.add(miEliminar);
        setJMenuBar(menuBar);

        miAgregar.addActionListener(e -> mostrarAgregar());
        miListar.addActionListener(e -> mostrarListar());
        miBuscar.addActionListener(e -> mostrarBuscar());
        miEditar.addActionListener(e -> mostrarEditar());
        miEliminar.addActionListener(e -> mostrarEliminar());
    }

    private void mostrarAgregar() {
        JTextField txtCodigo = new JTextField();
        JTextField txtDescripcion = new JTextField();
        JTextField txtPrecio = new JTextField();
        JTextField txtDuracion = new JTextField();
        JTextField txtDestino = new JTextField();
        JTextField txtGuia = new JTextField();

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("Código:")); panel.add(txtCodigo);
        panel.add(new JLabel("Descripción:")); panel.add(txtDescripcion);
        panel.add(new JLabel("Precio:")); panel.add(txtPrecio);
        panel.add(new JLabel("Duración:")); panel.add(txtDuracion);
        panel.add(new JLabel("Destino Ciudad:")); panel.add(txtDestino);
        panel.add(new JLabel("Guía Nombre:")); panel.add(txtGuia);

        int result = JOptionPane.showConfirmDialog(this, panel, "Nuevo Paquete",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                String codigo = txtCodigo.getText();
                String descripcion = txtDescripcion.getText();
                double precio = Double.parseDouble(txtPrecio.getText());
                int duracion = Integer.parseInt(txtDuracion.getText());
                Destino destino = new Destino(txtDestino.getText(), "", "");
                GuiaTuristico guia = new GuiaTuristico(txtGuia.getText(), "", 0);
                List<Turista> turistas = new ArrayList<>();

                controlador.agregarPaquete(codigo, descripcion, precio, duracion, destino, guia, turistas);
                JOptionPane.showMessageDialog(this, "Paquete agregado con éxito");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Datos inválidos. Verifica los campos numéricos.");
            }
        }
    }

    private void mostrarListar() {
        List<PaqueteTuristico> lista = controlador.obtenerTodos();
        StringBuilder sb = new StringBuilder();
        for (PaqueteTuristico p : lista) {
            sb.append("Código: ").append(p.getCodigo()).append(" | ")
              .append("Desc: ").append(p.getDescripcion()).append(" | ")
              .append("Precio: ").append(p.getPrecio()).append("\n");
        }
        if (lista.isEmpty()) sb.append("No hay paquetes disponibles.");
        JOptionPane.showMessageDialog(this, sb.toString(), "Lista de Paquetes", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarBuscar() {
        String codigo = JOptionPane.showInputDialog(this, "Código a buscar:");
        if (codigo != null) {
            PaqueteTuristico p = controlador.buscarPorCodigo(codigo);
            if (p != null) {
                JOptionPane.showMessageDialog(this, "Encontrado: " + p.getDescripcion() + " | $" + p.getPrecio());
            } else {
                JOptionPane.showMessageDialog(this, "Paquete no encontrado.");
            }
        }
    }

    private void mostrarEditar() {
        String codigo = JOptionPane.showInputDialog(this, "Código a editar:");
        PaqueteTuristico existente = controlador.buscarPorCodigo(codigo);
        if (existente == null) {
            JOptionPane.showMessageDialog(this, "Paquete no encontrado.");
            return;
        }

        JTextField txtDescripcion = new JTextField(existente.getDescripcion());
        JTextField txtPrecio = new JTextField(String.valueOf(existente.getPrecio()));
        JTextField txtDuracion = new JTextField(String.valueOf(existente.getDuracionDias()));

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("Nueva descripción:")); panel.add(txtDescripcion);
        panel.add(new JLabel("Nuevo precio:")); panel.add(txtPrecio);
        panel.add(new JLabel("Nueva duración:")); panel.add(txtDuracion);

        int result = JOptionPane.showConfirmDialog(this, panel, "Editar Paquete",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                String descripcion = txtDescripcion.getText();
                double precio = Double.parseDouble(txtPrecio.getText());
                int duracion = Integer.parseInt(txtDuracion.getText());

                controlador.editarPaquete(codigo, descripcion, precio, duracion,
                        existente.getDestino(), existente.getGuia(), existente.getTuristas());
                JOptionPane.showMessageDialog(this, "Paquete actualizado");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error en los datos ingresados.");
            }
        }
    }

    private void mostrarEliminar() {
        String codigo = JOptionPane.showInputDialog(this, "Código a eliminar:");
        if (codigo != null) {
            boolean eliminado = controlador.eliminarPorCodigo(codigo);
            JOptionPane.showMessageDialog(this, eliminado ? "Eliminado con éxito" : "No se encontró el paquete");
        }
    }
}

