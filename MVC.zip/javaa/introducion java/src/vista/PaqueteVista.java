package vista;

import controlador.PaqueteControlador;
import modelo.PaqueteTuristico;
import vista.EstiloSwing;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PaqueteVista extends JPanel {
    private JTextField txtNombre, txtDescripcion, txtPrecio, txtDuracion, txtGuiaId, txtLugarId;
    private JTextField txtBuscarNombre;
    private JTable tabla;
    private DefaultTableModel modelo;
    private PaqueteControlador controlador;

    public PaqueteVista() {
        controlador = new PaqueteControlador(this, new dao.PaqueteTuristicoDAO());
        setLayout(new BorderLayout());
        setBackground(EstiloSwing.COLOR_FONDO);

        JPanel formPanel = new JPanel(new GridLayout(7, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createTitledBorder("Nuevo Paquete Turístico"));
        formPanel.setBackground(EstiloSwing.COLOR_FONDO);

        JLabel lblTitulo = new JLabel("Gestión de Paquetes Turísticos");
        lblTitulo.setFont(EstiloSwing.FUENTE_TITULO);
        lblTitulo.setForeground(EstiloSwing.COLOR_PRIMARIO);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);

        txtNombre = new JTextField();         formPanel.add(new JLabel("Nombre:"));       formPanel.add(txtNombre);
        txtDescripcion = new JTextField();    formPanel.add(new JLabel("Descripción:"));  formPanel.add(txtDescripcion);
        txtPrecio = new JTextField();         formPanel.add(new JLabel("Precio:"));       formPanel.add(txtPrecio);
        txtDuracion = new JTextField();       formPanel.add(new JLabel("Duración (días):")); formPanel.add(txtDuracion);
        txtLugarId = new JTextField();        formPanel.add(new JLabel("ID Lugar:"));     formPanel.add(txtLugarId);
        txtGuiaId = new JTextField();         formPanel.add(new JLabel("ID Guía:"));      formPanel.add(txtGuiaId);
        txtBuscarNombre = new JTextField();   formPanel.add(new JLabel("Buscar por nombre:")); formPanel.add(txtBuscarNombre);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(EstiloSwing.COLOR_VERDE_CLARO);

        JButton btnGuardar = new JButton("Guardar");
        JButton btnBuscarNombre = new JButton("Buscar nombre");

        estilizarBoton(btnGuardar);
        estilizarBoton(btnBuscarNombre);

        buttonPanel.add(btnGuardar);
        buttonPanel.add(btnBuscarNombre);

        modelo = new DefaultTableModel(new String[]{
            "ID", "Nombre", "Descripción", "Precio", "Duración", "Lugar ID", "Guía ID"
        }, 0);
        tabla = new JTable(modelo);
        tabla.setRowHeight(26);
        tabla.setFont(EstiloSwing.FUENTE_NORMAL);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder("Paquetes Registrados"));

        btnGuardar.addActionListener(e -> {
            PaqueteTuristico p = new PaqueteTuristico(
                0,
                txtNombre.getText(),
                txtDescripcion.getText(),
                Double.parseDouble(txtPrecio.getText()),
                Integer.parseInt(txtDuracion.getText()),
                Integer.parseInt(txtLugarId.getText()),
                Integer.parseInt(txtGuiaId.getText())
            );

            if (controlador.guardar(p)) {
                JOptionPane.showMessageDialog(this, "✅ Paquete guardado");
                listar();
                limpiar();
            } else {
                JOptionPane.showMessageDialog(this, "❌ Error al guardar paquete");
            }
        });

        btnBuscarNombre.addActionListener(e -> {
            List<PaqueteTuristico> resultados = controlador.buscarPorNombre(txtBuscarNombre.getText().trim());
            actualizarTabla(resultados);
        });

        add(lblTitulo, BorderLayout.NORTH);
        add(formPanel, BorderLayout.WEST);
        add(buttonPanel, BorderLayout.CENTER);
        add(scroll, BorderLayout.SOUTH);

        listar();
    }

    private void listar() {
        actualizarTabla(controlador.listar());
    }

    private void actualizarTabla(List<PaqueteTuristico> datos) {
        modelo.setRowCount(0);
        for (PaqueteTuristico p : datos) {
            modelo.addRow(new Object[]{
                p.getId(),
                p.getNombre(),
                p.getDescripcion(),
                p.getPrecio(),
                p.getDuracionDias(),
                p.getLugarId(),
                p.getGuiaId()
            });
        }
    }

    private void limpiar() {
        txtNombre.setText("");
        txtDescripcion.setText("");
        txtPrecio.setText("");
        txtDuracion.setText("");
        txtLugarId.setText("");
        txtGuiaId.setText("");
        txtBuscarNombre.setText("");
    }

    private void estilizarBoton(JButton boton) {
        boton.setBackground(EstiloSwing.COLOR_PRIMARIO);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(EstiloSwing.FUENTE_NORMAL);
        boton.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
    }
}