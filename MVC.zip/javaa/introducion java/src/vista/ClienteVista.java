package vista;

import controlador.ClienteControlador;
import modelo.Cliente;
import vista.EstiloSwing;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ClienteVista extends JPanel {
    private JTextField txtNombre, txtCorreo, txtTelefono, txtDocumento, txtNacionalidad;
    private JTextField txtBuscarNombre, txtBuscarDocumento;
    private JTable tabla;
    private DefaultTableModel modelo;
    private ClienteControlador controlador;

    public ClienteVista() {
        controlador = new ClienteControlador(this, new dao.ClienteDAO());
        setLayout(new BorderLayout());
        setBackground(EstiloSwing.COLOR_FONDO);

        JPanel formPanel = new JPanel(new GridLayout(7, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createTitledBorder("Nuevo Cliente"));
        formPanel.setBackground(EstiloSwing.COLOR_FONDO);

        JLabel lblTitulo = new JLabel("Gestión de Clientes");
        lblTitulo.setFont(EstiloSwing.FUENTE_TITULO);
        lblTitulo.setForeground(EstiloSwing.COLOR_PRIMARIO);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);

        txtNombre = new JTextField();       formPanel.add(new JLabel("Nombre:"));       formPanel.add(txtNombre);
        txtCorreo = new JTextField();       formPanel.add(new JLabel("Correo:"));       formPanel.add(txtCorreo);
        txtTelefono = new JTextField();     formPanel.add(new JLabel("Teléfono:"));     formPanel.add(txtTelefono);
        txtDocumento = new JTextField();    formPanel.add(new JLabel("Documento:"));    formPanel.add(txtDocumento);
        txtNacionalidad = new JTextField(); formPanel.add(new JLabel("Nacionalidad:")); formPanel.add(txtNacionalidad);
        txtBuscarNombre = new JTextField(); formPanel.add(new JLabel("Buscar por nombre:")); formPanel.add(txtBuscarNombre);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(EstiloSwing.COLOR_FONDO);

        JButton btnGuardar = new JButton("Guardar");
        JButton btnBuscarNombre = new JButton("Buscar nombre");
        JButton btnBuscarDocumento = new JButton("Buscar documento");

        estilizarBoton(btnGuardar);
        estilizarBoton(btnBuscarNombre);
        estilizarBoton(btnBuscarDocumento);

        buttonPanel.add(btnGuardar);
        buttonPanel.add(btnBuscarNombre);
        buttonPanel.add(btnBuscarDocumento);

        modelo = new DefaultTableModel(new String[]{"ID", "Nombre", "Correo", "Teléfono", "Documento", "Nacionalidad"}, 0);
        tabla = new JTable(modelo);
        tabla.setRowHeight(26);
        tabla.setFont(EstiloSwing.FUENTE_NORMAL);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder("Clientes Registrados"));

        btnGuardar.addActionListener(e -> {
            Cliente c = new Cliente(
                0,
                txtNombre.getText(),
                txtCorreo.getText(),
                txtTelefono.getText(),
                txtDocumento.getText(),
                txtNacionalidad.getText()
            );

            if (controlador.guardar(c)) {
                JOptionPane.showMessageDialog(this, "✅ Cliente registrado");
                listar();
                limpiar();
            } else {
                JOptionPane.showMessageDialog(this, "❌ Error al registrar cliente");
            }
        });

        btnBuscarNombre.addActionListener(e -> {
            List<Cliente> resultados = controlador.buscarPorNombre(txtBuscarNombre.getText().trim());
            actualizarTabla(resultados);
        });

        btnBuscarDocumento.addActionListener(e -> {
            Cliente resultado = controlador.buscarPorDocumento(txtDocumento.getText().trim());
            modelo.setRowCount(0);
            if (resultado != null) {
                modelo.addRow(new Object[]{
                    resultado.getId(),
                    resultado.getNombre(),
                    resultado.getCorreo(),
                    resultado.getTelefono(),
                    resultado.getDocumento(),
                    resultado.getNacionalidad()
                });
            } else {
                JOptionPane.showMessageDialog(this, "❌ No se encontró cliente");
            }
        });

        add(lblTitulo, BorderLayout.NORTH);
        add(formPanel, BorderLayout.WEST);
        add(buttonPanel, BorderLayout.CENTER);
        add(scroll, BorderLayout.SOUTH);

        listar();
    }

    private void listar() {
        actualizarTabla(controlador.listar());
    }

    private void actualizarTabla(List<Cliente> datos) {
        modelo.setRowCount(0);
        for (Cliente c : datos) {
            modelo.addRow(new Object[]{
                c.getId(),
                c.getNombre(),
                c.getCorreo(),
                c.getTelefono(),
                c.getDocumento(),
                c.getNacionalidad()
            });
        }
    }

    private void limpiar() {
        txtNombre.setText("");
        txtCorreo.setText("");
        txtTelefono.setText("");
        txtDocumento.setText("");
        txtNacionalidad.setText("");
        txtBuscarNombre.setText("");
    }

    private void estilizarBoton(JButton boton) {
        boton.setBackground(EstiloSwing.COLOR_PRIMARIO);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(EstiloSwing.FUENTE_NORMAL);
        boton.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
    }
}