package vista;

import java.awt.*;
import javax.swing.*;

public class VistaProducto extends JFrame {
    private JTextField txtNombre = new JTextField(20);
    private JTextField txtPrecio = new JTextField(10);
    private JTextField txtCantidad = new JTextField(10);
    private JButton btnCalcular = new JButton("Calcular Total");
    private JLabel lblResultado = new JLabel("Total: ");

    public VistaProducto() {
        setTitle("Registro de Producto");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5, 2));

        add(new JLabel("Nombre:"));
        add(txtNombre);
        add(new JLabel("Precio:"));
        add(txtPrecio);
        add(new JLabel("Cantidad:"));
        add(txtCantidad);
        add(btnCalcular);
        add(lblResultado);
    }

    public String getNombre() {
        return txtNombre.getText();
    }
    public String getPrecio() {
        return txtPrecio.getText();
    }
    public String getCantidad() {
        return txtCantidad.getText();
    }
    public void setResultado(String resultado) {
        lblResultado.setText("Total: " + resultado);
    }
    public JButton getBtnCalcular() {
        return btnCalcular;
    }
}
