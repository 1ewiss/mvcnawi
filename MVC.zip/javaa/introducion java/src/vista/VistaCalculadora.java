package vista;

import java.awt.*;
import javax.swing.*;

public class VistaCalculadora extends JFrame {
    private JTextField txtA = new JTextField(10);
    private JTextField txtB = new JTextField(10);
    private JComboBox<String> cmbOperacion = new JComboBox<>(new String[]{"Suma", "Resta", "Multiplicación", "División"});
    private JButton btnCalcular = new JButton("Calcular");
    private JLabel lblResultado = new JLabel("Resultado: ");

    public VistaCalculadora() {
        setTitle("Calculadora Básica");
        setSize(350, 150);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2));

        add(new JLabel("Número A:"));
        add(txtA);
        add(new JLabel("Número B:"));
        add(txtB);
        add(new JLabel("Operación:"));
        add(cmbOperacion);
        add(btnCalcular);
        add(lblResultado);
    }

    public String getA() {
        return txtA.getText();
    }
    public String getB() {
        return txtB.getText();
    }
    public String getOperacion() {
        return (String) cmbOperacion.getSelectedItem();
    }
    public void setResultado(String resultado) {
        lblResultado.setText("Resultado: " + resultado);
    }
    public JButton getBtnCalcular() {
        return btnCalcular;
    }
}
