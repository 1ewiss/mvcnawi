package vista;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class LugarVista extends JPanel {
    public JTextField txtId, txtNombre, txtUbicacion, txtCategoria, txtBuscar;
    public JTextArea txtDescripcion;
    public JButton btnGuardar, btnActualizar, btnEliminar, btnBuscar;
    public JTable tablaLugares;
    public DefaultTableModel modeloTabla;

    public LugarVista() {
        setLayout(new BorderLayout());

        JPanel panelFormulario = new JPanel(new GridLayout(6, 2, 8, 8));
        panelFormulario.setBorder(BorderFactory.createTitledBorder("Datos del lugar"));

        txtId = new JTextField(); txtId.setEditable(false);
        txtNombre = new JTextField();
        txtUbicacion = new JTextField();
        txtDescripcion = new JTextArea(3, 20);
        txtCategoria = new JTextField();

        panelFormulario.add(new JLabel("ID:")); panelFormulario.add(txtId);
        panelFormulario.add(new JLabel("Nombre:")); panelFormulario.add(txtNombre);
        panelFormulario.add(new JLabel("Ubicación:")); panelFormulario.add(txtUbicacion);
        panelFormulario.add(new JLabel("Descripción:")); panelFormulario.add(new JScrollPane(txtDescripcion));
        panelFormulario.add(new JLabel("Categoría:")); panelFormulario.add(txtCategoria);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnGuardar = new JButton("Guardar");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        txtBuscar = new JTextField(15);
        btnBuscar = new JButton("Buscar");

        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(new JLabel("Buscar por nombre:"));
        panelBotones.add(txtBuscar);
        panelBotones.add(btnBuscar);

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Nombre", "Ubicación", "Descripción", "Categoría"}, 0);
        tablaLugares = new JTable(modeloTabla);
        JScrollPane scrollTabla = new JScrollPane(tablaLugares);
        scrollTabla.setBorder(BorderFactory.createTitledBorder("Lugares registrados"));

        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.add(panelFormulario, BorderLayout.CENTER);
        panelSuperior.add(panelBotones, BorderLayout.SOUTH);

        add(panelSuperior, BorderLayout.NORTH);
        add(scrollTabla, BorderLayout.CENTER);
    }
}