package vista;

import controlador.ClienteControlador;
import controlador.GuiaControlador;
import controlador.LugarControlador;
import controlador.PaqueteControlador;
import controlador.ReservaControlador;
import dao.ClienteDAO;
import dao.GuiaDAO;
import dao.LugarDAO;
import dao.PaqueteTuristicoDAO;
import dao.ReservaDAO;
import java.awt.*;
import java.io.File;
import javax.swing.*;

public class MainMenuVista extends JFrame {
    private CardLayout cardLayout;
    private JPanel panelContenedor;

    public MainMenuVista() {
        setTitle("Marca Ñawi - Agencia Turística");
        setSize(1000, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cardLayout = new CardLayout();
        panelContenedor = new JPanel(cardLayout);
        panelContenedor.setBackground(new Color(0xF5F5DC)); // fondo crema

        // 🏞️ Panel Home con imagen de fondo y texto estilizado
        JPanel panelHome = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon fondo = new ImageIcon("src/recursos/inicio.jpg");
                g.drawImage(fondo.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        panelHome.setLayout(null);

        JLabel lblInicio = new JLabel("Bienvenido a Ñawi ", JLabel.CENTER);
        lblInicio.setBounds(0, 40, 1000, 80);
        lblInicio.setForeground(new Color(0xE14B3D)); // rojo anaranjado

        // Fuente personalizada Montserrat
        try {
            Font customFont = Font.createFont(
                Font.TRUETYPE_FONT,
                new File("src/recursos/fonts/Montserrat-Bold.ttf")
            ).deriveFont(48f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(customFont);
            lblInicio.setFont(customFont);
        } catch (Exception e) {
            lblInicio.setFont(new Font("SansSerif", Font.BOLD, 48));
        }

        panelHome.add(lblInicio);

        // 🔌 Inicializar vistas y controladores
        LugarVista lugarVista = new LugarVista();
        new LugarControlador(lugarVista, new LugarDAO());

        GuiaVista guiaVista = new GuiaVista();
        new GuiaControlador(guiaVista, new GuiaDAO());

        ReservaVista reservaVista = new ReservaVista();
        new ReservaControlador(reservaVista, new ReservaDAO());

        PaqueteVista paqueteVista = new PaqueteVista();
        new PaqueteControlador(paqueteVista, new PaqueteTuristicoDAO());

        ClienteVista clienteVista = new ClienteVista();
        new ClienteControlador(clienteVista, new ClienteDAO());

        // ➕ Agregar vistas al contenedor
        panelContenedor.add(panelHome, "home");
        panelContenedor.add(lugarVista, "lugares");
        panelContenedor.add(guiaVista, "guias");
        panelContenedor.add(reservaVista, "reservas");
        panelContenedor.add(paqueteVista, "paquetes");
        panelContenedor.add(clienteVista, "clientes");

        // 📋 Menú superior estilizado
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(0x2F4F4F)); // verde oscuro

        JMenu menuInicio = new JMenu("Inicio");
        JMenu menuModulo = new JMenu("Módulos");
        menuInicio.setForeground(Color.WHITE);
        menuModulo.setForeground(Color.WHITE);

        JMenuItem itemHome = new JMenuItem("Página Principal");
        JMenuItem itemLugares = new JMenuItem("Lugares Turísticos");
        JMenuItem itemGuias = new JMenuItem("Guías Turísticos");
        JMenuItem itemReservas = new JMenuItem("Reservas");
        JMenuItem itemPaquetes = new JMenuItem("Paquetes Turísticos");
        JMenuItem itemClientes = new JMenuItem("Clientes");

        itemHome.addActionListener(e -> cardLayout.show(panelContenedor, "home"));
        itemLugares.addActionListener(e -> cardLayout.show(panelContenedor, "lugares"));
        itemGuias.addActionListener(e -> cardLayout.show(panelContenedor, "guias"));
        itemReservas.addActionListener(e -> cardLayout.show(panelContenedor, "reservas"));
        itemPaquetes.addActionListener(e -> cardLayout.show(panelContenedor, "paquetes"));
        itemClientes.addActionListener(e -> cardLayout.show(panelContenedor, "clientes"));

        menuInicio.add(itemHome);
        menuModulo.add(itemLugares);
        menuModulo.add(itemGuias);
        menuModulo.add(itemReservas);
        menuModulo.add(itemPaquetes);
        menuModulo.add(itemClientes);

        menuBar.add(menuInicio);
        menuBar.add(menuModulo);

        setJMenuBar(menuBar);
        add(panelContenedor);
        cardLayout.show(panelContenedor, "home");
    }
}