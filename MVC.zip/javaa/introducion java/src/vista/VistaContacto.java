package vista;

import java.awt.*;
import javax.swing.*;

public class VistaContacto extends JFrame {
    private JTextField txtNombre = new JTextField(20);
    private JTextField txtEmail = new JTextField(20);
    private JTextField txtTelefono = new JTextField(15);
    private JButton btnMostrar = new JButton("Mostrar");
    private JLabel lblResultado = new JLabel("Contacto:");

    public VistaContacto() {
        setTitle("Formulario de Contacto");
        setSize(350, 180);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5, 2));

        add(new JLabel("Nombre:"));
        add(txtNombre);
        add(new JLabel("Email:"));
        add(txtEmail);
        add(new JLabel("Teléfono:"));
        add(txtTelefono);
        add(btnMostrar);
        add(lblResultado);
    }

    public String getNombre() {
        return txtNombre.getText();
    }
    public String getEmail() {
        return txtEmail.getText();
    }
    public String getTelefono() {
        return txtTelefono.getText();
    }
    public void setResultado(String resultado) {
        lblResultado.setText(resultado);
    }
    public JButton getBtnMostrar() {
        return btnMostrar;
    }
}
