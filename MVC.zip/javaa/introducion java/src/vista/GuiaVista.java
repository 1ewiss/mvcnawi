package vista;

import controlador.GuiaControlador;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.Guia;

public class GuiaVista extends JPanel {
    private JTextField txtNombre, txtEspecialidad, txtIdiomas, txtTelefono, txtBuscar;
    private JTable tabla;
    private DefaultTableModel modelo;
    private GuiaControlador controlador;

    public GuiaVista() {
        controlador = new GuiaControlador(this, new dao.GuiaDAO());
        setLayout(new BorderLayout());

        // 📋 Formulario
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createTitledBorder("Datos del guía"));

        formPanel.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        formPanel.add(txtNombre);

        formPanel.add(new JLabel("Especialidad:"));
        txtEspecialidad = new JTextField();
        formPanel.add(txtEspecialidad);

        formPanel.add(new JLabel("Idiomas:"));
        txtIdiomas = new JTextField();
        formPanel.add(txtIdiomas);

        formPanel.add(new JLabel("Teléfono:"));
        txtTelefono = new JTextField();
        formPanel.add(txtTelefono);

        formPanel.add(new JLabel("Buscar por nombre:"));
        txtBuscar = new JTextField();
        formPanel.add(txtBuscar);

        // 🎯 Botones
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton btnGuardar = new JButton("Guardar");
        JButton btnBuscar = new JButton("Buscar");
        buttonPanel.add(btnGuardar);
        buttonPanel.add(btnBuscar);

        // 🖥️ Tabla
        modelo = new DefaultTableModel(new String[]{"ID", "Nombre", "Especialidad", "Idiomas", "Teléfono"}, 0);
        tabla = new JTable(modelo);
        tabla.setRowHeight(26);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder("Listado de guías"));

        // 🧠 Acciones
        btnGuardar.addActionListener(e -> {
            Guia g = new Guia(0,
                    txtNombre.getText(),
                    txtEspecialidad.getText(),
                    txtIdiomas.getText(),
                    txtTelefono.getText());

            if (controlador.guardar(g)) {
                JOptionPane.showMessageDialog(this, "✅ Guía guardado correctamente.");
                listar();
                limpiar();
            } else {
                JOptionPane.showMessageDialog(this, "❌ Error al guardar guía.");
            }
        });

        btnBuscar.addActionListener(e -> {
            String nombre = txtBuscar.getText().trim();
            List<Guia> resultados = controlador.buscarPorNombre(nombre);
            actualizarTabla(resultados);
        });

        // 🧱 Estructura
        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(scroll, BorderLayout.SOUTH);

        listar(); // carga inicial
    }

    private void listar() {
        List<Guia> guias = controlador.listar();
        actualizarTabla(guias);
    }

    private void actualizarTabla(List<Guia> datos) {
        modelo.setRowCount(0);
        for (Guia g : datos) {
            modelo.addRow(new Object[]{
                g.getId(),
                g.getNombre(),
                g.getEspecialidad(),
                g.getIdiomas(),
                g.getTelefono()
            });
        }
    }

    private void limpiar() {
        txtNombre.setText("");
        txtEspecialidad.setText("");
        txtIdiomas.setText("");
        txtTelefono.setText("");
        txtBuscar.setText("");
    }
}