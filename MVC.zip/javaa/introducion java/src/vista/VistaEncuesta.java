package vista;

import java.awt.*;
import javax.swing.*;

public class VistaEncuesta extends JFrame {
    private JTextField txtNombre = new JTextField(20);
    private JComboBox<Integer> cmbNivel = new JComboBox<>(new Integer[]{1, 2, 3, 4, 5});
    private JButton btnEnviar = new JButton("Enviar");
    private JLabel lblResultado = new JLabel("Resultado:");

    public VistaEncuesta() {
        setTitle("Encuesta de Satisfacción");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2));

        add(new JLabel("Nombre:"));
        add(txtNombre);
        add(new JLabel("Nivel (1-5):"));
        add(cmbNivel);
        add(btnEnviar);
        add(lblResultado);
    }

    public String getNombre() {
        return txtNombre.getText();
    }
    public int getNivel() {
        return (Integer) cmbNivel.getSelectedItem();
    }
    public void setResultado(String resultado) {
        lblResultado.setText(resultado);
    }
    public JButton getBtnEnviar() {
        return btnEnviar;
    }
}

