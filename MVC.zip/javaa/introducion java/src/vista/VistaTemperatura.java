package vista;

import java.awt.*;
import javax.swing.*;

public class VistaTemperatura extends JFrame {
    private JTextField txtTemperatura = new JTextField(10);
    private JComboBox<String> cmbConversion = new JComboBox<>(new String[]{"C a F", "F a C"});
    private JButton btnConvertir = new JButton("Convertir");
    private JLabel lblResultado = new JLabel("Resultado: ");

    public VistaTemperatura() {
        setTitle("Conversor de Temperatura");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2));

        add(new JLabel("Temperatura:"));
        add(txtTemperatura);
        add(new JLabel("Conversión:"));
        add(cmbConversion);
        add(btnConvertir);
        add(lblResultado);
    }

    public String getTemperatura() {
        return txtTemperatura.getText();
    }
    public String getConversion() {
        return (String) cmbConversion.getSelectedItem();
    }
    public void setResultado(String resultado) {
        lblResultado.setText("Resultado: " + resultado);
    }
    public JButton getBtnConvertir() {
        return btnConvertir;
    }
}
