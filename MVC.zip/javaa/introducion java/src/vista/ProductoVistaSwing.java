package vista;

import controlador.ProductoControlador;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.Producto;

public class ProductoVistaSwing extends JFrame {
    private ProductoControlador controlador;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JTextField txtNombre, txtDescripcion, txtPrecio, txtId;

    public ProductoVistaSwing() {
        controlador = new ProductoControlador();
        setTitle("CRUD de Productos");
        setSize(700, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        modeloTabla = new DefaultTableModel(new String[]{"ID", "Nombre", "Descripción", "Precio"}, 0);
        tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane, BorderLayout.CENTER);

        JPanel panelForm = new JPanel(new GridLayout(4, 2));
        txtId = new JTextField();
        txtNombre = new JTextField();
        txtDescripcion = new JTextField();
        txtPrecio = new JTextField();

        panelForm.add(new JLabel("ID:"));
        panelForm.add(txtId);
        panelForm.add(new JLabel("Nombre:"));
        panelForm.add(txtNombre);
        panelForm.add(new JLabel("Descripción:"));
        panelForm.add(txtDescripcion);
        panelForm.add(new JLabel("Precio:"));
        panelForm.add(txtPrecio);

        add(panelForm, BorderLayout.NORTH);

        // Panel de botones en la parte inferior
        JPanel panelBotones = new JPanel(new FlowLayout());

        JButton btnAgregar = new JButton("Agregar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");

        btnAgregar.addActionListener(e -> agregarProducto());
        btnActualizar.addActionListener(e -> actualizarProducto());
        btnEliminar.addActionListener(e -> eliminarProducto());
        btnLimpiar.addActionListener(e -> limpiarCampos());

        panelBotones.add(btnAgregar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);

        add(panelBotones, BorderLayout.SOUTH);

        cargarDatos();

        tabla.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int fila = tabla.getSelectedRow();
                txtId.setText(modeloTabla.getValueAt(fila, 0).toString());
                txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
                txtDescripcion.setText(modeloTabla.getValueAt(fila, 2).toString());
                txtPrecio.setText(modeloTabla.getValueAt(fila, 3).toString());
            }
        });
    }

    private void cargarDatos() {
        modeloTabla.setRowCount(0);
        List<Producto> productos = controlador.listarProductos();
        for (Producto p : productos) {
            modeloTabla.addRow(new Object[]{p.getId(), p.getNombre(), p.getDescripcion(), p.getPrecio()});
        }
    }

    private void agregarProducto() {
        Producto p = new Producto();
        p.setNombre(txtNombre.getText());
        p.setDescripcion(txtDescripcion.getText());
        p.setPrecio(Double.parseDouble(txtPrecio.getText()));
        controlador.guardarProducto(p);
        cargarDatos();
        limpiarCampos();
    }

    private void actualizarProducto() {
        Producto p = new Producto();
        p.setId(Integer.parseInt(txtId.getText()));
        p.setNombre(txtNombre.getText());
        p.setDescripcion(txtDescripcion.getText());
        p.setPrecio(Double.parseDouble(txtPrecio.getText()));
        controlador.editarProducto(p);
        cargarDatos();
        limpiarCampos();
    }

    private void eliminarProducto() {
        int id = Integer.parseInt(txtId.getText());
        controlador.eliminarProducto(id);
        cargarDatos();
        limpiarCampos();
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtNombre.setText("");
        txtDescripcion.setText("");
        txtPrecio.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductoVistaSwing().setVisible(true));
    }
}

