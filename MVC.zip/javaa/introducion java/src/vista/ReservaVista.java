package vista;

import controlador.ReservaControlador;
import modelo.Reserva;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class ReservaVista extends JPanel {
    private JTextField txtClienteId, txtPaqueteId, txtPersonas, txtBuscarCliente;
    private JFormattedTextField txtFecha;
    private JTable tabla;
    private DefaultTableModel modelo;
    private ReservaControlador controlador;

    public ReservaVista() {
        controlador = new ReservaControlador(this, new dao.ReservaDAO());
        setLayout(new BorderLayout());

        // 🧾 Formulario
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createTitledBorder("Nueva reserva"));

        formPanel.add(new JLabel("ID Cliente:"));
        txtClienteId = new JTextField();
        formPanel.add(txtClienteId);

        formPanel.add(new JLabel("ID Paquete:"));
        txtPaqueteId = new JTextField();
        formPanel.add(txtPaqueteId);

        formPanel.add(new JLabel("Fecha (YYYY-MM-DD):"));
        txtFecha = new JFormattedTextField();
        formPanel.add(txtFecha);

        formPanel.add(new JLabel("Personas:"));
        txtPersonas = new JTextField();
        formPanel.add(txtPersonas);

        formPanel.add(new JLabel("Buscar por ID Cliente:"));
        txtBuscarCliente = new JTextField();
        formPanel.add(txtBuscarCliente);

        // 🧠 Botones
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton btnGuardar = new JButton("Guardar");
        JButton btnBuscar = new JButton("Buscar");
        buttonPanel.add(btnGuardar);
        buttonPanel.add(btnBuscar);

        // 📋 Tabla
        modelo = new DefaultTableModel(new String[]{"ID", "Cliente", "Paquete", "Fecha", "Personas"}, 0);
        tabla = new JTable(modelo);
        tabla.setRowHeight(26);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder("Reservas registradas"));

        // 🧩 Acciones
        btnGuardar.addActionListener(e -> {
            try {
                int clienteId = Integer.parseInt(txtClienteId.getText());
                int paqueteId = Integer.parseInt(txtPaqueteId.getText());
                LocalDate fecha = LocalDate.parse(txtFecha.getText().trim());
                int personas = Integer.parseInt(txtPersonas.getText());

                Reserva r = new Reserva(0, clienteId, paqueteId, fecha, personas);

                if (controlador.guardar(r)) {
                    JOptionPane.showMessageDialog(this, "✅ Reserva registrada");
                    listar();
                    limpiar();
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Error al registrar reserva");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "⚠️ Verifica los datos ingresados");
            }
        });

        btnBuscar.addActionListener(e -> {
            try {
                int clienteId = Integer.parseInt(txtBuscarCliente.getText());
                List<Reserva> resultados = controlador.buscarPorCliente(clienteId);
                actualizarTabla(resultados);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "⚠️ Ingresa un ID válido");
            }
        });

        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(scroll, BorderLayout.SOUTH);

        listar(); // carga inicial
    }

    private void listar() {
        List<Reserva> reservas = controlador.listar();
        actualizarTabla(reservas);
    }

    private void actualizarTabla(List<Reserva> datos) {
        modelo.setRowCount(0);
        for (Reserva r : datos) {
            modelo.addRow(new Object[]{
                r.getId(),
                r.getClienteId(),
                r.getPaqueteId(),
                r.getFecha(),
                r.getPersonas()
            });
        }
    }

    private void limpiar() {
        txtClienteId.setText("");
        txtPaqueteId.setText("");
        txtFecha.setText("");
        txtPersonas.setText("");
        txtBuscarCliente.setText("");
    }
}