import ejemplo.cedula.Persona;

public class maain {
    public static void main(String[] args) {
        // Crear objeto usando la clase correcta
        Persona persona1 = new Persona("Alex", 18, "0606440824");

        // Mostrar datos
        persona1.mostrarDatos();

        // Verificar si es mayor de edad
        if (persona1.esMayorDeEdad()) {
            System.out.println("Es mayor de edad.");
        } else {
            System.out.println("No es mayor de edad.");
        }
    }
}
