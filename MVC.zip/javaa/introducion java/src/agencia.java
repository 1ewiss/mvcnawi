import vista.LugarVista;
import dao.LugarDAO;
import controlador.LugarControlador;

public class agencia {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            LugarVista vista = new LugarVista();
            LugarDAO dao = new LugarDAO();
            new LugarControlador(vista, dao);
            vista.setVisible(true);
        });
    }
}
