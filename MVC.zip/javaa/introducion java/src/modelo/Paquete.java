package modelo;

public class Paquete {
    private int id;
    private String nombre;
    private String descripcion;
    private double precio;
    private int duracionDias;
    private int lugarId;
    private int guiaId;

    public Paquete(int id, String nombre, String descripcion, double precio, int duracionDias, int lugarId, int guiaId) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.duracionDias = duracionDias;
        this.lugarId = lugarId;
        this.guiaId = guiaId;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public double getPrecio() { return precio; }
    public int getDuracionDias() { return duracionDias; }
    public int getLugarId() { return lugarId; }
    public int getGuiaId() { return guiaId; }
}