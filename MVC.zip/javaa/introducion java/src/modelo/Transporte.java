package modelo;

public class Transporte {
    private String tipo;
    private String empresa;

    public Transporte(String tipo, String empresa) {
        this.tipo = tipo;
        this.empresa = empresa;
    }

    public String getTipo() { return tipo; }
    public String getEmpresa() { return empresa; }
}
