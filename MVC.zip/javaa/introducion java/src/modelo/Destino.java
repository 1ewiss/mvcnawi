package modelo;

public class Destino {
    private String ciudad;
    private String pais;
    private String descripcion;

    public Destino(String ciudad, String pais, String descripcion) {
        this.ciudad = ciudad;
        this.pais = pais;
        this.descripcion = descripcion;
    }

    public String getCiudad() { return ciudad; }
    public String getPais() { return pais; }
    public String getDescripcion() { return descripcion; }

    public void setCiudad(String ciudad) { this.ciudad = ciudad; }
    public void setPais(String pais) { this.pais = pais; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
