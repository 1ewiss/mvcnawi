package modelo;

import java.util.List;

public class PaqueteTuristicoPlus {
    private int id;
    private String nombre;
    private double precio;
    private DestinoViaje destino;
    private ClienteViaje cliente;
    private List<ActividadViaje> actividades;

    // Constructor vacío
    public PaqueteTuristicoPlus() {}

    // Constructor con parámetros
    public PaqueteTuristicoPlus(int id, String nombre, double precio, DestinoViaje destino,
                                 ClienteViaje cliente, List<ActividadViaje> actividades) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.destino = destino;
        this.cliente = cliente;
        this.actividades = actividades;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public DestinoViaje getDestino() {
        return destino;
    }

    public void setDestino(DestinoViaje destino) {
        this.destino = destino;
    }

    public ClienteViaje getCliente() {
        return cliente;
    }

    public void setCliente(ClienteViaje cliente) {
        this.cliente = cliente;
    }

    public List<ActividadViaje> getActividades() {
        return actividades;
    }

    public void setActividades(List<ActividadViaje> actividades) {
        this.actividades = actividades;
    }
}
