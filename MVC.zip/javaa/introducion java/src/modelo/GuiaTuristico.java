package modelo;

public class GuiaTuristico {
    private String nombre;
    private String idioma;
    private int experienciaAnios;

    public GuiaTuristico(String nombre, String idioma, int experienciaAnios) {
        this.nombre = nombre;
        this.idioma = idioma;
        this.experienciaAnios = experienciaAnios;
    }

    public String getNombre() { return nombre; }
    public String getIdioma() { return idioma; }
    public int getExperienciaAnios() { return experienciaAnios; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setIdioma(String idioma) { this.idioma = idioma; }
    public void setExperienciaAnios(int experienciaAnios) { this.experienciaAnios = experienciaAnios; }
}
