package modelo;

public class Guia {
    private int id;
    private String nombre;
    private String especialidad;
    private String idiomas;
    private String telefono;

    public Guia(int id, String nombre, String especialidad, String idiomas, String telefono) {
        this.id = id;
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.idiomas = idiomas;
        this.telefono = telefono;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public String getIdiomas() {
        return idiomas;
    }

    public String getTelefono() {
        return telefono;
    }

    @Override
    public String toString() {
        return nombre + " (" + especialidad + ")";
    }
}