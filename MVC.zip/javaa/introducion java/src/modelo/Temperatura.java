package modelo;

public class Temperatura {
    public double celsiusAFahrenheit(double c) {
        return (c * 9/5) + 32;
    }
    public double fahrenheitACelsius(double f) {
        return (f - 32) * 5/9;
    }
}
