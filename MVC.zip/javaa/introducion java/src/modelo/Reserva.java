package modelo;

import java.time.LocalDate;

public class Reserva {
    private int id;
    private int clienteId;
    private int paqueteId;
    private LocalDate fecha;
    private int personas;

    public Reserva(int id, int clienteId, int paqueteId, LocalDate fecha, int personas) {
        this.id = id;
        this.clienteId = clienteId;
        this.paqueteId = paqueteId;
        this.fecha = fecha;
        this.personas = personas;
    }

    public int getId() {
        return id;
    }

    public int getClienteId() {
        return clienteId;
    }

    public int getPaqueteId() {
        return paqueteId;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getPersonas() {
        return personas;
    }

    @Override
    public String toString() {
        return "Reserva{" +
                "id=" + id +
                ", clienteId=" + clienteId +
                ", paqueteId=" + paqueteId +
                ", fecha=" + fecha +
                ", personas=" + personas +
                '}';
    }
}