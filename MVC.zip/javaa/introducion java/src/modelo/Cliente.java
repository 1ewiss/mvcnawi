package modelo;

public class Cliente {
    private int id;
    private String nombre;
    private String correo;
    private String telefono;
    private String documento;
    private String nacionalidad;

    public Cliente(int id, String nombre, String correo, String telefono, String documento, String nacionalidad) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.documento = documento;
        this.nacionalidad = nacionalidad;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getCorreo() { return correo; }
    public String getTelefono() { return telefono; }
    public String getDocumento() { return documento; }
    public String getNacionalidad() { return nacionalidad; }

    @Override
    public String toString() {
        return nombre + " (" + documento + ")";
    }
}