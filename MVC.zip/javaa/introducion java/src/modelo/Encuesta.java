package modelo;

public class Encuesta {
    private String nombre;
    private int nivel;

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public String resumen() {
        return "Gracias " + nombre + ", puntuaste con un " + nivel + " de 5.";
    }
}
