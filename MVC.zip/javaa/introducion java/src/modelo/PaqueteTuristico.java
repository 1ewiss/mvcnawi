package modelo;

public class PaqueteTuristico {
    private int id;
    private String nombre;
    private String descripcion;
    private double precio;
    private int duracionDias;
    private int lugarId;
    private int guiaId;

    public PaqueteTuristico() {
    }

    public PaqueteTuristico(int id, String nombre, String descripcion, double precio,
                            int duracionDias, int lugarId, int guiaId) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.duracionDias = duracionDias;
        this.lugarId = lugarId;
        this.guiaId = guiaId;
    }

    // Getters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public double getPrecio() { return precio; }
    public int getDuracionDias() { return duracionDias; }
    public int getLugarId() { return lugarId; }
    public int getGuiaId() { return guiaId; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public void setPrecio(double precio) { this.precio = precio; }
    public void setDuracionDias(int duracionDias) { this.duracionDias = duracionDias; }
    public void setLugarId(int lugarId) { this.lugarId = lugarId; }
    public void setGuiaId(int guiaId) { this.guiaId = guiaId; }
}