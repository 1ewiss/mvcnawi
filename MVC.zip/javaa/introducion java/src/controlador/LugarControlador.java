package controlador;

import vista.LugarVista;
import dao.LugarDAO;
import modelo.LugarTuristico;

import javax.swing.*;
import java.awt.event.*;
import java.util.List;

public class LugarControlador {
    private LugarVista vista;
    private LugarDAO dao;

    public LugarControlador(LugarVista vista, LugarDAO dao) {
        this.vista = vista;
        this.dao = dao;
        agregarListeners();
        cargarTabla(dao.listar());
    }

    private void agregarListeners() {
        vista.btnGuardar.addActionListener(e -> guardarLugar());
        vista.btnActualizar.addActionListener(e -> actualizarLugar());
        vista.btnEliminar.addActionListener(e -> eliminarLugar());
        vista.btnBuscar.addActionListener(e -> buscarLugar());

        vista.tablaLugares.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int fila = vista.tablaLugares.getSelectedRow();
                if (fila >= 0) {
                    vista.txtId.setText(vista.tablaLugares.getValueAt(fila, 0).toString());
                    vista.txtNombre.setText(vista.tablaLugares.getValueAt(fila, 1).toString());
                    vista.txtUbicacion.setText(vista.tablaLugares.getValueAt(fila, 2).toString());
                    vista.txtDescripcion.setText(vista.tablaLugares.getValueAt(fila, 3).toString());
                    vista.txtCategoria.setText(vista.tablaLugares.getValueAt(fila, 4).toString());
                }
            }
        });
    }

    private void guardarLugar() {
        LugarTuristico lugar = new LugarTuristico();
        lugar.setNombre(vista.txtNombre.getText());
        lugar.setUbicacion(vista.txtUbicacion.getText());
        lugar.setDescripcion(vista.txtDescripcion.getText());
        lugar.setCategoria(vista.txtCategoria.getText());

        if (dao.insertar(lugar)) {
            JOptionPane.showMessageDialog(null, "✅ Lugar guardado correctamente.");
            limpiarCampos();
            cargarTabla(dao.listar());
        } else {
            JOptionPane.showMessageDialog(null, "❌ Error al guardar.");
        }
    }

    private void actualizarLugar() {
        if (vista.txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "⚠️ Selecciona un lugar en la tabla para actualizar.");
            return;
        }

        LugarTuristico lugar = new LugarTuristico();
        lugar.setId(Integer.parseInt(vista.txtId.getText()));
        lugar.setNombre(vista.txtNombre.getText());
        lugar.setUbicacion(vista.txtUbicacion.getText());
        lugar.setDescripcion(vista.txtDescripcion.getText());
        lugar.setCategoria(vista.txtCategoria.getText());

        if (dao.actualizar(lugar)) {
            JOptionPane.showMessageDialog(null, "🔄 Lugar actualizado.");
            limpiarCampos();
            cargarTabla(dao.listar());
        } else {
            JOptionPane.showMessageDialog(null, "❌ Error al actualizar.");
        }
    }

    private void eliminarLugar() {
        if (vista.txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "⚠️ Selecciona un lugar en la tabla para eliminar.");
            return;
        }

        int id = Integer.parseInt(vista.txtId.getText());
        int confirmar = JOptionPane.showConfirmDialog(null, "¿Eliminar este lugar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            if (dao.eliminar(id)) {
                JOptionPane.showMessageDialog(null, "🗑️ Lugar eliminado.");
                limpiarCampos();
                cargarTabla(dao.listar());
            } else {
                JOptionPane.showMessageDialog(null, "❌ Error al eliminar.");
            }
        }
    }

    private void buscarLugar() {
        String nombre = vista.txtBuscar.getText();
        List<LugarTuristico> resultados = dao.buscarPorNombre(nombre);
        cargarTabla(resultados);
    }

    private void limpiarCampos() {
        vista.txtId.setText("");
        vista.txtNombre.setText("");
        vista.txtUbicacion.setText("");
        vista.txtDescripcion.setText("");
        vista.txtCategoria.setText("");
        vista.txtBuscar.setText("");
    }

    private void cargarTabla(List<LugarTuristico> lugares) {
        vista.modeloTabla.setRowCount(0);
        for (LugarTuristico l : lugares) {
            vista.modeloTabla.addRow(new Object[]{
                l.getId(), l.getNombre(), l.getUbicacion(), l.getDescripcion(), l.getCategoria()
            });
        }
    }
}