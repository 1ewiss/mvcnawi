package controlador;

import vista.PaqueteVista;
import dao.PaqueteTuristicoDAO;
import modelo.PaqueteTuristico;

import java.util.List;

public class PaqueteControlador {
    private PaqueteVista vista;
    private PaqueteTuristicoDAO dao;

    public PaqueteControlador(PaqueteVista vista, PaqueteTuristicoDAO dao) {
        this.vista = vista;
        this.dao = dao;
    }

    public boolean guardar(PaqueteTuristico p) {
        return dao.guardar(p);
    }

    public List<PaqueteTuristico> listar() {
        return dao.listar();
    }

    public List<PaqueteTuristico> buscarPorNombre(String nombre) {
        return dao.buscarPorNombre(nombre);
    }

    public List<PaqueteTuristico> buscarPorPrecio(double min, double max) {
        return dao.buscarPorPrecio(min, max);
    }
}
