package controlador;

import modelo.*;

import java.util.ArrayList;
import java.util.List;

public class ControladorPaqueteTuristico {
    private List<PaqueteTuristico> listaPaquetes;

    public ControladorPaqueteTuristico() {
        listaPaquetes = new ArrayList<>();
    }

    public void agregarPaquete(String codigo, String descripcion, double precio, int duracionDias,
                               Destino destino, GuiaTuristico guia, List<Turista> turistas) {
        PaqueteTuristico paquete = new PaqueteTuristico(codigo, descripcion, precio, duracionDias, destino, guia, turistas);
        listaPaquetes.add(paquete);
    }

    public List<PaqueteTuristico> obtenerTodos() {
        return listaPaquetes;
    }

    public PaqueteTuristico buscarPorCodigo(String codigo) {
        for (PaqueteTuristico p : listaPaquetes) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                return p;
            }
        }
        return null;
    }

    public boolean eliminarPorCodigo(String codigo) {
        PaqueteTuristico paquete = buscarPorCodigo(codigo);
        if (paquete != null) {
            return listaPaquetes.remove(paquete);
        }
        return false;
    }

    public boolean editarPaquete(String codigo, String descripcion, double precio, int duracionDias,
                                  Destino destino, GuiaTuristico guia, List<Turista> turistas) {
        PaqueteTuristico paquete = buscarPorCodigo(codigo);
        if (paquete != null) {
            paquete.setDescripcion(descripcion);
            paquete.setPrecio(precio);
            paquete.setDuracionDias(duracionDias);
            paquete.setDestino(destino);
            paquete.setGuia(guia);
            paquete.setTuristas(turistas);
            return true;
        }
        return false;
    }
}
