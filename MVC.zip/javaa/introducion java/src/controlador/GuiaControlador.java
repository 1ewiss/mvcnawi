package controlador;

import modelo.Guia;
import vista.GuiaVista;
import dao.GuiaDAO;

import java.util.List;

public class GuiaControlador {
    private GuiaVista vista;
    private GuiaDAO dao;

    public GuiaControlador(GuiaVista vista, GuiaDAO dao) {
        this.vista = vista;
        this.dao = dao;
    }

    public boolean guardar(Guia g) {
        return dao.insertar(g);
    }

    public List<Guia> listar() {
        return dao.listarTodos();
    }

    public List<Guia> buscarPorNombre(String nombre) {
        return dao.buscarPorNombre(nombre);
    }
}
