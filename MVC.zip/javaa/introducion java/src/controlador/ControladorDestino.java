package controlador;

import modelo.Destino;
import java.util.ArrayList;
import java.util.List;

public class ControladorDestino {
    private List<Destino> destinos = new ArrayList<>();

    public void agregar(Destino d) { destinos.add(d); }

    public List<Destino> listar() { return destinos; }

    public Destino buscar(String ciudad) {
        for (Destino d : destinos) {
            if (d.getCiudad().equalsIgnoreCase(ciudad)) return d;
        }
        return null;
    }

    public boolean eliminar(String ciudad) {
        return destinos.removeIf(d -> d.getCiudad().equalsIgnoreCase(ciudad));
    }

    public void editar(String ciudad, String nuevoPais, String nuevaDescripcion) {
        Destino d = buscar(ciudad);
        if (d != null) {
            destinos.remove(d);
            destinos.add(new Destino(ciudad, nuevoPais, nuevaDescripcion));
        }
    }
}
