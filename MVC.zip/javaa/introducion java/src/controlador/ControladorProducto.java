package controlador;

import modelo.Producto;
import vista.VistaProducto;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorProducto implements ActionListener {
    private Producto modelo;
    private VistaProducto vista;

    public ControladorProducto(Producto modelo, VistaProducto vista) {
        this.modelo = modelo;
        this.vista = vista;
        this.vista.getBtnCalcular().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            String nombre = vista.getNombre();
            double precio = Double.parseDouble(vista.getPrecio());
            int cantidad = Integer.parseInt(vista.getCantidad());

            modelo.setNombre(nombre);
            modelo.setPrecio(precio);
            modelo.setCantidad(cantidad);

            double total = modelo.calcularTotal();
            vista.setResultado(String.format("%.2f", total));
        } catch (NumberFormatException ex) {
            vista.setResultado("Error: Precio y cantidad deben ser numéricos");
        }
    }
}
