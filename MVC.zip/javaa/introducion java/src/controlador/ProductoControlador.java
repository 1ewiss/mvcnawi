package controlador;

import dao.ProductoDAO;
import dao.ProductoDAOImpl;
import modelo.Producto;
import java.util.List;

public class ProductoControlador {
    private ProductoDAO dao = new ProductoDAOImpl();

    public boolean guardarProducto(Producto p) { return dao.agregar(p); }
    public boolean editarProducto(Producto p) { return dao.actualizar(p); }
    public boolean eliminarProducto(int id) { return dao.eliminar(id); }
    public Producto obtenerProducto(int id) { return dao.obtenerPorId(id); }
    public List<Producto> listarProductos() { return dao.listarTodos(); }
}