package controlador;

import modelo.Cliente;
import vista.ClienteVista;
import dao.ClienteDAO;

import java.util.List;

public class ClienteControlador {
    private ClienteVista vista;
    private ClienteDAO dao;

    public ClienteControlador(ClienteVista vista, ClienteDAO dao) {
        this.vista = vista;
        this.dao = dao;
    }

    public boolean guardar(Cliente c) {
        return dao.insertar(c);
    }

    public List<Cliente> listar() {
        return dao.listarTodos();
    }

    public List<Cliente> buscarPorNombre(String nombre) {
        return dao.buscarPorNombre(nombre);
    }

    public Cliente buscarPorDocumento(String documento) {
        return dao.buscarPorDocumento(documento);
    }
}