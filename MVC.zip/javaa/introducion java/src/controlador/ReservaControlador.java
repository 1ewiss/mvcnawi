package controlador;

import modelo.Reserva;
import vista.ReservaVista;
import dao.ReservaDAO;

import java.time.LocalDate;
import java.util.List;

public class ReservaControlador {
    private ReservaVista vista;
    private ReservaDAO dao;

    public ReservaControlador(ReservaVista vista, ReservaDAO dao) {
        this.vista = vista;
        this.dao = dao;
    }

    public boolean guardar(Reserva r) {
        return dao.insertar(r);
    }

    public List<Reserva> listar() {
        return dao.listarTodos();
    }

    public List<Reserva> buscarPorCliente(int clienteId) {
        return dao.buscarPorCliente(clienteId);
    }

    public List<Reserva> buscarPorFecha(LocalDate fecha) {
        return dao.buscarPorFecha(fecha);
    }
}
