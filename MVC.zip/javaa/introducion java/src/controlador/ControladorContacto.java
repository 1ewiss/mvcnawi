package controlador;

import modelo.Contacto;
import vista.VistaContacto;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorContacto implements ActionListener {
    private Contacto modelo;
    private VistaContacto vista;

    public ControladorContacto(Contacto modelo, VistaContacto vista) {
        this.modelo = modelo;
        this.vista = vista;
        this.vista.getBtnMostrar().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String nombre = vista.getNombre();
        String email = vista.getEmail();
        String telefono = vista.getTelefono();

        modelo.setNombre(nombre);
        modelo.setEmail(email);
        modelo.setTelefono(telefono);

        vista.setResultado(modelo.mostrar());
    }
}
