package controlador;

import modelo.Encuesta;
import vista.VistaEncuesta;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorEncuesta implements ActionListener {
    private Encuesta modelo;
    private VistaEncuesta vista;

    public ControladorEncuesta(Encuesta modelo, VistaEncuesta vista) {
        this.modelo = modelo;
        this.vista = vista;
        this.vista.getBtnEnviar().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String nombre = vista.getNombre();
        int nivel = vista.getNivel();

        modelo.setNombre(nombre);
        modelo.setNivel(nivel);

        vista.setResultado(modelo.resumen());
    }
}
