package controlador;

import modelo.Calculadora;
import vista.VistaCalculadora;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorCalculadora implements ActionListener {
    private Calculadora modelo;
    private VistaCalculadora vista;

    public ControladorCalculadora(Calculadora modelo, VistaCalculadora vista) {
        this.modelo = modelo;
        this.vista = vista;
        this.vista.getBtnCalcular().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            double a = Double.parseDouble(vista.getA());
            double b = Double.parseDouble(vista.getB());
            String op = vista.getOperacion();

            double resultado = modelo.operar(a, b, op);
            vista.setResultado(String.format("%.2f", resultado));
        } catch (NumberFormatException ex) {
            vista.setResultado("Error: Números inválidos");
        }
    }
}
