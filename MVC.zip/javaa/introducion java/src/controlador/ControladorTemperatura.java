package controlador;

import modelo.Temperatura;
import vista.VistaTemperatura;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorTemperatura implements ActionListener {
    private Temperatura modelo;
    private VistaTemperatura vista;

    public ControladorTemperatura(Temperatura modelo, VistaTemperatura vista) {
        this.modelo = modelo;
        this.vista = vista;
        this.vista.getBtnConvertir().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            double temp = Double.parseDouble(vista.getTemperatura());
            String op = vista.getConversion();
            double resultado = 0;

            if ("C a F".equals(op)) {
                resultado = modelo.celsiusAFahrenheit(temp);
            } else if ("F a C".equals(op)) {
                resultado = modelo.fahrenheitACelsius(temp);
            }

            vista.setResultado(String.format("%.2f", resultado));
        } catch (NumberFormatException ex) {
            vista.setResultado("Error: Temperatura inválida");
        }
    }
}
