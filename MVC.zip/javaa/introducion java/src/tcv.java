import view.TemperatureConverterView;

public class tcv {
    public static void main(String[] args) {
        new TemperatureConverterView();
    }
}
