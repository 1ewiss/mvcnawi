import javax.swing.SwingUtilities;
import vista.MainMenuVista;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainMenuVista().setVisible(true);
        });
    }
}
