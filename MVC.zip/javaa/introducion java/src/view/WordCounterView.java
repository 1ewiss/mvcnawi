package view;

import logic.WordCounter;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WordCounterView extends JFrame {
    private JTextArea inputArea, resultadoArea;
    private JButton contarButton;

    public WordCounterView() {
        setTitle("Contador de Palabras");
        setSize(350, 300);
        setLayout(null);

        JLabel inputLabel = new JLabel("Texto:");
        inputLabel.setBounds(10, 10, 100, 20);
        add(inputLabel);

        inputArea = new JTextArea();
        JScrollPane inputScroll = new JScrollPane(inputArea);
        inputScroll.setBounds(10, 35, 310, 100);
        add(inputScroll);

        contarButton = new JButton("Contar Palabras");
        contarButton.setBounds(10, 140, 310, 30);
        add(contarButton);

        resultadoArea = new JTextArea();
        resultadoArea.setBounds(10, 180, 310, 60);
        resultadoArea.setEditable(false);
        resultadoArea.setLineWrap(true);
        resultadoArea.setWrapStyleWord(true);
        add(resultadoArea);

        WordCounter counter = new WordCounter();
        contarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String texto = inputArea.getText();
                int cantidad = counter.contarPalabras(texto);
                resultadoArea.setText("Número de palabras: " + cantidad);
            }
        });

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
}
