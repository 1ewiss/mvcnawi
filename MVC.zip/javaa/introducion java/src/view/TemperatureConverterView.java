package view;

import logic.TemperatureConverter;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TemperatureConverterView extends JFrame {
    private JTextField celsiusField, resultadoField;
    private JButton convertirButton;

    public TemperatureConverterView() {
        setTitle("Conversor de Temperatura");
        setSize(300, 180);
        setLayout(null);

        JLabel celsiusLabel = new JLabel("Celsius:");
        celsiusLabel.setBounds(10, 10, 100, 20);
        add(celsiusLabel);

        celsiusField = new JTextField();
        celsiusField.setBounds(120, 10, 100, 20);
        add(celsiusField);

        convertirButton = new JButton("Convertir");
        convertirButton.setBounds(10, 50, 210, 30);
        add(convertirButton);

        resultadoField = new JTextField();
        resultadoField.setBounds(10, 90, 210, 20);
        resultadoField.setEditable(false);
        add(resultadoField);

        TemperatureConverter converter = new TemperatureConverter();
        convertirButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double celsius = Double.parseDouble(celsiusField.getText());
                    double fahrenheit = converter.celsiusToFahrenheit(celsius);
                    resultadoField.setText(String.format("Fahrenheit: %.2f", fahrenheit));
                } catch (NumberFormatException ex) {
                    resultadoField.setText("Entrada inválida.");
                }
            }
        });

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
}
