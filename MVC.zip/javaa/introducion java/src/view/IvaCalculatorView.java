package view;

import logic.IvaCalculator;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class IvaCalculatorView extends JFrame {
    private JTextField precioField, porcentajeField, resultadoField;
    private JButton calcularButton;

    public IvaCalculatorView() {
        setTitle("Calculadora de IVA");
        setSize(300, 200);
        setLayout(null);

        JLabel precioLabel = new JLabel("Precio:");
        precioLabel.setBounds(10, 10, 100, 20);
        add(precioLabel);

        precioField = new JTextField();
        precioField.setBounds(120, 10, 100, 20);
        add(precioField);

        JLabel porcentajeLabel = new JLabel("IVA %:");
        porcentajeLabel.setBounds(10, 40, 100, 20);
        add(porcentajeLabel);

        porcentajeField = new JTextField();
        porcentajeField.setBounds(120, 40, 100, 20);
        add(porcentajeField);

        calcularButton = new JButton("Calcular");
        calcularButton.setBounds(10, 70, 210, 30);
        add(calcularButton);

        resultadoField = new JTextField();
        resultadoField.setBounds(10, 110, 210, 20);
        resultadoField.setEditable(false);
        add(resultadoField);

        IvaCalculator calculator = new IvaCalculator();
        calcularButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                double precio = Double.parseDouble(precioField.getText());
                double porcentaje = Double.parseDouble(porcentajeField.getText());
                double iva = calculator.calcularIVA(precio, porcentaje);
                resultadoField.setText(String.format("IVA: %.2f", iva));
            }
        });

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
}
