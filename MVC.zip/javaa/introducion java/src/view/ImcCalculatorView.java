package view;

import logic.ImcCalculator;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ImcCalculatorView extends JFrame {
    private JTextField pesoField, alturaField;
    private JTextArea resultadoField;
    private JButton calcularButton;

    public ImcCalculatorView() {
        setTitle("Calculadora de IMC");
        setSize(300, 230);
        setLayout(null);

        JLabel pesoLabel = new JLabel("Peso (kg):");
        pesoLabel.setBounds(10, 10, 100, 20);
        add(pesoLabel);

        pesoField = new JTextField();
        pesoField.setBounds(120, 10, 100, 20);
        add(pesoField);

        JLabel alturaLabel = new JLabel("Altura (m):");
        alturaLabel.setBounds(10, 40, 100, 20);
        add(alturaLabel);

        alturaField = new JTextField();
        alturaField.setBounds(120, 40, 100, 20);
        add(alturaField);

        calcularButton = new JButton("Calcular IMC");
        calcularButton.setBounds(10, 70, 210, 30);
        add(calcularButton);

        resultadoField = new JTextArea();
        resultadoField.setBounds(10, 110, 210, 60);
        resultadoField.setEditable(false);
        resultadoField.setLineWrap(true);
        resultadoField.setWrapStyleWord(true);
        add(resultadoField);

        ImcCalculator calculator = new ImcCalculator();
        calcularButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double peso = Double.parseDouble(pesoField.getText());
                    double altura = Double.parseDouble(alturaField.getText());

                    double imc = calculator.calcularIMC(peso, altura);
                    String categoria = calculator.obtenerCategoria(imc);

                    resultadoField.setText(String.format("IMC: %.2f\nCategoría: %s", imc, categoria));
                } catch (NumberFormatException ex) {
                    resultadoField.setText("Entrada inválida. Usa números.");
                } catch (IllegalArgumentException ex) {
                    resultadoField.setText(ex.getMessage());
                }
            }
        });

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
}
