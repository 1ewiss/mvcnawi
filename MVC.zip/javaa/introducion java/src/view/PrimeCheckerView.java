package view;

import logic.PrimeChecker;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PrimeCheckerView extends JFrame {
    private JTextField numeroField, resultadoField;
    private JButton verificarButton;

    public PrimeCheckerView() {
        setTitle("Verificador de Número Primo");
        setSize(300, 180);
        setLayout(null);

        JLabel numeroLabel = new JLabel("Número:");
        numeroLabel.setBounds(10, 10, 100, 20);
        add(numeroLabel);

        numeroField = new JTextField();
        numeroField.setBounds(120, 10, 100, 20);
        add(numeroField);

        verificarButton = new JButton("Verificar");
        verificarButton.setBounds(10, 50, 210, 30);
        add(verificarButton);

        resultadoField = new JTextField();
        resultadoField.setBounds(10, 90, 210, 20);
        resultadoField.setEditable(false);
        add(resultadoField);

        PrimeChecker checker = new PrimeChecker();
        verificarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int numero = Integer.parseInt(numeroField.getText());
                    boolean primo = checker.esPrimo(numero);
                    resultadoField.setText(primo ? "Es primo" : "No es primo");
                } catch (NumberFormatException ex) {
                    resultadoField.setText("Entrada inválida.");
                }
            }
        });

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
}
