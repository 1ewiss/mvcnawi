public class ConObjetos {
    private static int contador = 0;
    private int numObjeto;

    public ConObjetos() {
        contador++;
        this.numObjeto = contador;
        System.out.println("Se creó el objeto #" + numObjeto);
    }

    public static void mostrarCantidadDeObjetos() {
        System.out.println("Total de objetos creados: " + contador);
    }

    
    public static void main(String[] args) {
        ConObjetos c1 = new ConObjetos();
        ConObjetos c2 = new ConObjetos();
        ConObjetos c3 = new ConObjetos();

        ConObjetos.mostrarCantidadDeObjetos();
    }
}