import java.util.ArrayList;

public class Cliente {
    private String nombre;
    private String correo;
    private ArrayList<Pedido> pedidos;

    public Cliente(String nombre, String correo) {
        this.nombre = nombre;
        this.correo = correo;
        this.pedidos = new ArrayList<>();
    }

    public void agregarPedido(Pedido pedido) {
        pedidos.add(pedido);
    }

    public void mostrarPedidos() {
        System.out.println("Cliente: " + nombre);
        System.out.println("Correo: " + correo);
        System.out.println("Pedidos:");
        for (Pedido p : pedidos) {
            p.mostrarPedido();
        }
    }

    public static void main(String[] args) {
        Cliente cliente1 = new Cliente("Neiver", "NeiverBazan78@gmail.com");

        Pedido pedido1 = new Pedido("laptop", 2, 1500.00);
        Pedido pedido2 = new Pedido("telefono", 1, 600.00);

        cliente1.agregarPedido(pedido1);
        cliente1.agregarPedido(pedido2);

        cliente1.mostrarPedidos();
    }
}
