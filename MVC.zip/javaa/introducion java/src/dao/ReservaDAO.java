package dao;

import modelo.Reserva;
import conexion.ConexionDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservaDAO {

    public boolean insertar(Reserva r) {
        String sql = "INSERT INTO reserva(clienteId, paqueteId, fecha, personas) VALUES (?, ?, ?, ?)";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, r.getClienteId());
            ps.setInt(2, r.getPaqueteId());
            ps.setDate(3, Date.valueOf(r.getFecha()));
            ps.setInt(4, r.getPersonas());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al insertar reserva: " + e.getMessage());
            return false;
        }
    }

    public Reserva buscarPorId(int id) {
        String sql = "SELECT * FROM reserva WHERE id = ?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Reserva(
                    rs.getInt("id"),
                    rs.getInt("clienteId"),
                    rs.getInt("paqueteId"),
                    rs.getDate("fecha").toLocalDate(),
                    rs.getInt("personas")
                );
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar reserva: " + e.getMessage());
        }
        return null;
    }

    public boolean actualizar(Reserva r) {
        String sql = "UPDATE reserva SET clienteId=?, paqueteId=?, fecha=?, personas=? WHERE id=?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, r.getClienteId());
            ps.setInt(2, r.getPaqueteId());
            ps.setDate(3, Date.valueOf(r.getFecha()));
            ps.setInt(4, r.getPersonas());
            ps.setInt(5, r.getId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al actualizar reserva: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM reserva WHERE id = ?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al eliminar reserva: " + e.getMessage());
            return false;
        }
    }

    public List<Reserva> listarTodos() {
        List<Reserva> lista = new ArrayList<>();
        String sql = "SELECT * FROM reserva";
        try (Connection con = ConexionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(new Reserva(
                    rs.getInt("id"),
                    rs.getInt("clienteId"),
                    rs.getInt("paqueteId"),
                    rs.getDate("fecha").toLocalDate(),
                    rs.getInt("personas")
                ));
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al listar reservas: " + e.getMessage());
        }
        return lista;
    }
}