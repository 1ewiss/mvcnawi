package dao;

import java.sql.*;
import java.util.*;
import modelo.PaqueteTuristico;

public class PaqueteTuristicoDAO {
    private Connection conexion;

    public PaqueteTuristicoDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/agencia_turistica", "root", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean guardar(PaqueteTuristico p) {
        String sql = "INSERT INTO paquetes (nombre, descripcion, precio, duracion_dias, lugar_id, guia_id) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, p.getNombre());
            stmt.setString(2, p.getDescripcion());
            stmt.setDouble(3, p.getPrecio());
            stmt.setInt(4, p.getDuracionDias());
            stmt.setInt(5, p.getLugarId());
            stmt.setInt(6, p.getGuiaId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<PaqueteTuristico> listar() {
        List<PaqueteTuristico> lista = new ArrayList<>();
        String sql = "SELECT * FROM paquetes";
        try (Statement stmt = conexion.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                PaqueteTuristico p = new PaqueteTuristico(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getDouble("precio"),
                    rs.getInt("duracion_dias"),
                    rs.getInt("lugar_id"),
                    rs.getInt("guia_id")
                );
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<PaqueteTuristico> buscarPorNombre(String nombre) {
        List<PaqueteTuristico> resultados = new ArrayList<>();
        String sql = "SELECT * FROM paquetes WHERE nombre LIKE ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, "%" + nombre + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PaqueteTuristico p = new PaqueteTuristico(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getDouble("precio"),
                    rs.getInt("duracion_dias"),
                    rs.getInt("lugar_id"),
                    rs.getInt("guia_id")
                );
                resultados.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultados;
    }
}