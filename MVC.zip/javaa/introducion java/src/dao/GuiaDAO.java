package dao;

import modelo.Guia;
import conexion.ConexionDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GuiaDAO {

    public boolean insertar(Guia g) {
        String sql = "INSERT INTO guia(nombre, especialidad, idiomas, telefono) VALUES (?, ?, ?, ?)";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, g.getNombre());
            ps.setString(2, g.getEspecialidad());
            ps.setString(3, g.getIdiomas());
            ps.setString(4, g.getTelefono());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al insertar guía: " + e.getMessage());
            return false;
        }
    }

    public Guia buscarPorId(int id) {
        String sql = "SELECT * FROM guia WHERE id = ?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Guia(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("especialidad"),
                    rs.getString("idiomas"),
                    rs.getString("telefono")
                );
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar guía: " + e.getMessage());
        }
        return null;
    }

    public boolean actualizar(Guia g) {
        String sql = "UPDATE guia SET nombre=?, especialidad=?, idiomas=?, telefono=? WHERE id=?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, g.getNombre());
            ps.setString(2, g.getEspecialidad());
            ps.setString(3, g.getIdiomas());
            ps.setString(4, g.getTelefono());
            ps.setInt(5, g.getId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al actualizar guía: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM guia WHERE id = ?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al eliminar guía: " + e.getMessage());
            return false;
        }
    }

    public List<Guia> listarTodos() {
        List<Guia> lista = new ArrayList<>();
        String sql = "SELECT * FROM guia";
        try (Connection con = ConexionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(new Guia(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("especialidad"),
                    rs.getString("idiomas"),
                    rs.getString("telefono")
                ));
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al listar guías: " + e.getMessage());
        }
        return lista;
    }
}