package dao;

import conexion.ConexionDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.LugarTuristico;

public class LugarDAO {

    public boolean insertar(LugarTuristico l) {
        String sql = "INSERT INTO lugares(nombre, ubicacion, descripcion, categoria) VALUES (?, ?, ?, ?)";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, l.getNombre());
            ps.setString(2, l.getUbicacion());
            ps.setString(3, l.getDescripcion());
            ps.setString(4, l.getCategoria());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al insertar lugar: " + e.getMessage());
            return false;
        }
    }

    public LugarTuristico buscarPorId(int id) {
        String sql = "SELECT * FROM lugares WHERE id = ?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new LugarTuristico(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("ubicacion"),
                    rs.getString("descripcion"),
                    rs.getString("categoria")
                );
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al buscar lugar: " + e.getMessage());
        }
        return null;
    }

    public boolean actualizar(LugarTuristico l) {
        String sql = "UPDATE lugares SET nombre=?, ubicacion=?, descripcion=?, categoria=? WHERE id=?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, l.getNombre());
            ps.setString(2, l.getUbicacion());
            ps.setString(3, l.getDescripcion());
            ps.setString(4, l.getCategoria());
            ps.setInt(5, l.getId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al actualizar lugar: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM lugares WHERE id = ?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al eliminar lugar: " + e.getMessage());
            return false;
        }
    }

    // ✅ Método que usa la GUI (alias de listarTodos)
    public List<LugarTuristico> listar() {
        return listarTodos();
    }

    public List<LugarTuristico> listarTodos() {
        List<LugarTuristico> lista = new ArrayList<>();
        String sql = "SELECT * FROM lugares";

        try (Connection con = ConexionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(new LugarTuristico(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("ubicacion"),
                    rs.getString("descripcion"),
                    rs.getString("categoria")
                ));
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al listar lugares: " + e.getMessage());
        }

        return lista;
    }

    // ✅ Método usado por la vista para búsquedas
    public List<LugarTuristico> buscarPorNombre(String nombre) {
        List<LugarTuristico> lista = new ArrayList<>();
        String sql = "SELECT * FROM lugares WHERE nombre LIKE ?";

        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + nombre + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(new LugarTuristico(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("ubicacion"),
                    rs.getString("descripcion"),
                    rs.getString("categoria")
                ));
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al buscar lugar por nombre: " + e.getMessage());
        }

        return lista;
    }
}