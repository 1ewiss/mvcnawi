package dao;

import modelo.Actividad;
import conexion.ConexionDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ActividadDAO {

    public boolean insertar(Actividad a) {
        String sql = "INSERT INTO actividad(nombre, tipo, nivel_dificultad, precio) VALUES (?, ?, ?, ?)";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, a.getNombre());
            ps.setString(2, a.getTipo());
            ps.setString(3, a.getNivelDificultad());
            ps.setDouble(4, a.getPrecio());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al insertar actividad: " + e.getMessage());
            return false;
        }
    }

    public Actividad buscarPorId(int id) {
        String sql = "SELECT * FROM actividad WHERE id = ?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Actividad(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("tipo"),
                    rs.getString("nivel_dificultad"),
                    rs.getDouble("precio")
                );
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar actividad: " + e.getMessage());
        }
        return null;
    }

    public boolean actualizar(Actividad a) {
        String sql = "UPDATE actividad SET nombre=?, tipo=?, nivel_dificultad=?, precio=? WHERE id=?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, a.getNombre());
            ps.setString(2, a.getTipo());
            ps.setString(3, a.getNivelDificultad());
            ps.setDouble(4, a.getPrecio());
            ps.setInt(5, a.getId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al actualizar actividad: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM actividad WHERE id = ?";
        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al eliminar actividad: " + e.getMessage());
            return false;
        }
    }

    public List<Actividad> listarTodos() {
        List<Actividad> lista = new ArrayList<>();
        String sql = "SELECT * FROM actividad";
        try (Connection con = ConexionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(new Actividad(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("tipo"),
                    rs.getString("nivel_dificultad"),
                    rs.getDouble("precio")
                ));
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al listar actividades: " + e.getMessage());
        }
        return lista;
    }
}