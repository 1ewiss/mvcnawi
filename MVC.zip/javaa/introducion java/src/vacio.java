import javax.swing.JFrame;

public class vacio {
    public static void main(String[] args) {
        
        JFrame frame = new JFrame("Mi JFrame");

        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        frame.setSize(400, 300);

        
        frame.setVisible(true);
    }
}
