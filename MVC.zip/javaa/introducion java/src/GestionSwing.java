import java.awt.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

public class GestionSwing extends JFrame {
    private JTextField campoNombre, campoEdad;
    private JTextArea areaSalida;
    private java.util.List<String> entradas = new ArrayList<>();

    public GestionSwing() {
        setTitle("Gestión de Datos");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel de entrada
        JPanel panelEntrada = new JPanel(new GridLayout(3, 2));
        panelEntrada.add(new JLabel("Nombre:"));
        campoNombre = new JTextField();
        panelEntrada.add(campoNombre);

        panelEntrada.add(new JLabel("Edad:"));
        campoEdad = new JTextField();
        panelEntrada.add(campoEdad);

        JButton botonGuardar = new JButton("Guardar");
        panelEntrada.add(botonGuardar);

        add(panelEntrada, BorderLayout.NORTH);

        // Área de salida
        areaSalida = new JTextArea();
        areaSalida.setEditable(false);
        add(new JScrollPane(areaSalida), BorderLayout.CENTER);

        // Acción del botón
        botonGuardar.addActionListener(e -> guardarDatos());
    }

    private void guardarDatos() {
        String nombre = campoNombre.getText().trim();
        String edadTexto = campoEdad.getText().trim();
        int edad;

        try {
            edad = Integer.parseInt(edadTexto);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Edad inválida. Ingrese un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String entrada = "Nombre: " + nombre + ", Edad: " + edad;
        entradas.add(entrada);

        try (FileWriter writer = new FileWriter("datos.txt", true)) {
            writer.write(entrada + "\n");
            writer.write("------------------------\n");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar archivo: " + ex.getMessage());
        }

        areaSalida.append(entrada + "\n");
        campoNombre.setText("");
        campoEdad.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GestionSwing().setVisible(true));
    }
}
