import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/tienda";
        String usuario = "root";
        String contraseña = ""; // ← tu contraseña aquí

        try {
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);
            System.out.println(" Conexión exitosa a la base de datos.");
            conexion.close();
        } catch (SQLException e) {
            System.out.println(" Error al conectar: " + e.getMessage());
        }
    }
}
